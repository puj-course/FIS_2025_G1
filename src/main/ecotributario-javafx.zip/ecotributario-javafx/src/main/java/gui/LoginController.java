package gui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class LoginController {

    @FXML private Button ingresarAdministradorButton;
    @FXML private Button ingresarEmpresaButton;

    @FXML
    private void ingresarAdministrador() {
        abrirVentana("/gui/LoginAdmin.fxml", "Ingreso Administrador");
    }

    @FXML
    private void ingresarEmpresa() {
        abrirVentana("/gui/LoginEmpresa.fxml", "Ingreso Empresa");
    }

    private void abrirVentana(String rutaFXML, String titulo) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Scene scene = new Scene(loader.load());

            Stage stage = new Stage();
            stage.setTitle(titulo);
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();

            // Cierra la ventana actual
            Stage ventanaActual = (Stage) ingresarAdministradorButton.getScene().getWindow();
            ventanaActual.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
