package gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;

public class DashboardController {

    @FXML
    private void cargarArchivo(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Selecciona un archivo .in");
        File archivo = fileChooser.showOpenDialog(new Stage());
        if (archivo != null) {
            System.out.println("Archivo cargado: " + archivo.getAbsolutePath());
        }
    }

    @FXML
    private void evaluarModelos(ActionEvent event) {
        System.out.println("Evaluando modelos...");
    }

    @FXML
    private void mostrarResultados(ActionEvent event) {
        System.out.println("Mostrando resultados...");
    }

    @FXML
    private void salirApp(ActionEvent event) {
        System.exit(0);
    }
}
