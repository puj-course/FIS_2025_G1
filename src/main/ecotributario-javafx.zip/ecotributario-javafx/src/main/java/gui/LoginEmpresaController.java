package gui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginEmpresaController {

    @FXML private TextField nitField;
    @FXML private PasswordField contrasenaField;

    @FXML
    private void iniciarSesion() {
        String nit = nitField.getText();
        String contrasena = contrasenaField.getText();

        if (!nit.isEmpty() && !contrasena.isEmpty()) {
            abrirDashboard();
        } else {
            System.out.println("❌ NIT o contraseña vacíos");
        }
    }

    private void abrirDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/Dashboard.fxml"));
            Scene scene = new Scene(loader.load());
            scene.getStylesheets().add(getClass().getResource("/gui/css/estilos.css").toExternalForm());

            Stage stage = new Stage();
            stage.setTitle("Panel Empresa");
            stage.setScene(scene);
            stage.setResizable(false);
            stage.show();

            Stage thisStage = (Stage) nitField.getScene().getWindow();
            thisStage.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
